@echo off
REM build_windows.bat - Windows一键编译

echo ╔══════════════════════════════════════════════════════╗
echo ║  P2P打洞系统 - Windows编译脚本                      ║
echo ╚══════════════════════════════════════════════════════╝
echo.

REM 检测编译器
where cl >nul 2>nul
if %errorlevel%==0 (
    echo [1] 使用 MSVC 编译...
    cl /EHsc /std:c++11 /O2 src\p2p.cpp /link ws2_32.lib winhttp.lib winmm.lib /OUT:p2p.exe
    goto :done
)

where g++ >nul 2>nul
if %errorlevel%==0 (
    echo [2] 使用 MinGW 编译...
    g++ -std=c++11 -O2 -o p2p.exe src/p2p.cpp -lws2_32 -lwinhttp -lwinmm
    goto :done
)

echo [X] 未找到编译器，请安装:
echo     - Visual Studio (cl.exe)
echo     - MinGW-w64 (g++)
echo     - 或使用 CMake + MSVC
pause
exit /b 1

:done
if exist p2p.exe (
    echo.
    echo ✅ 编译成功! 生成: p2p.exe
    echo.
    echo 使用示例:
    echo   信令服务器: p2p.exe server 8080
    echo   客户端:     p2p.exe client http://IP:8080 22 my-id
) else (
    echo ❌ 编译失败
    pause
    exit /b 1
)

pause