// src/p2p_enterprise.cpp
// 跨平台P2P打洞系统 - 自动适配Windows/Linux

#define _WIN32_WINNT 0x0600

#ifdef _WIN32
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <windows.h>
    #include <winhttp.h>
    #pragma comment(lib, "ws2_32.lib")
    #pragma comment(lib, "winhttp.lib")
    #pragma comment(lib, "winmm.lib")
    typedef SOCKET socket_t;
    typedef int socklen_t;
    #define CLOSE_SOCKET(s) closesocket(s)
    #define INVALID_SOCKET_VAL INVALID_SOCKET
    #define SLEEP_MS(ms) Sleep(ms)
    #define GET_PID() GetCurrentProcessId()
    #define HTTP_GET(url) http_get_win(url)
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <unistd.h>
    #include <fcntl.h>
    #include <signal.h>
    #include <curl/curl.h>
    typedef int socket_t;
    #define CLOSE_SOCKET(s) close(s)
    #define INVALID_SOCKET_VAL -1
    #define SLEEP_MS(ms) usleep((ms) * 1000)
    #define GET_PID() getpid()
    #define HTTP_GET(url) http_get_curl(url)
#endif

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <mutex>
#include <thread>
#include <chrono>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <ctime>

#define BUFFER_SIZE 8192
#define TIMEOUT_SECONDS 30
#define MAX_RETRY 10
#define MIN_ID_LENGTH 8
#define MAX_ID_LENGTH 1024
#define DEFAULT_PORT 8080
#define VERSION "3.0.0"

// ==================== 全局变量 ====================
struct ClientInfo {
    std::string id;
    std::string ip;
    int port;
    time_t last_seen;
    bool is_permanent;
};

std::map<std::string, ClientInfo> g_clients;
std::mutex g_clients_mutex;
bool g_running = true;
int GLOBAL_SERVICE_PORT = 5900;

// ==================== 工具函数 ====================
std::string url_encode(const std::string& str) {
    std::string encoded;
    for (char c : str) {
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            encoded += c;
        } else {
            char hex[4];
            snprintf(hex, sizeof(hex), "%%%02X", (unsigned char)c);
            encoded += hex;
        }
    }
    return encoded;
}

std::string extract_json_value(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\":\"";
    size_t start = json.find(search);
    if (start == std::string::npos) {
        search = "\"" + key + "\":";
        start = json.find(search);
        if (start == std::string::npos) return "";
        start += search.length();
        size_t end = json.find_first_of(",}", start);
        if (end == std::string::npos) return "";
        return json.substr(start, end - start);
    }
    start += search.length();
    size_t end = json.find("\"", start);
    if (end == std::string::npos) return "";
    return json.substr(start, end - start);
}

std::string trim(const std::string& str) {
    size_t start = str.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) return "";
    size_t end = str.find_last_not_of(" \t\n\r");
    return str.substr(start, end - start + 1);
}

// ==================== 平台特定HTTP实现 ====================
#ifdef _WIN32
std::string http_get_win(const std::string& url) {
    std::string response;
    std::string host, path;
    int port = 80;
    bool use_https = false;
    
    size_t pos = url.find("://");
    if (pos != std::string::npos) {
        std::string protocol = url.substr(0, pos);
        if (protocol == "https") { use_https = true; port = 443; }
        size_t start = pos + 3;
        size_t end = url.find("/", start);
        if (end != std::string::npos) {
            host = url.substr(start, end - start);
            path = url.substr(end);
        } else {
            host = url.substr(start);
            path = "/";
        }
        size_t colon = host.find(":");
        if (colon != std::string::npos) {
            port = atoi(host.substr(colon + 1).c_str());
            host = host.substr(0, colon);
        }
    } else {
        return response;
    }
    
    std::wstring whost = std::wstring(host.begin(), host.end());
    std::wstring wpath = std::wstring(path.begin(), path.end());
    
    HINTERNET hSession = WinHttpOpen(L"P2P Enterprise/3.0", 
                                     WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                                     WINHTTP_NO_PROXY_NAME,
                                     WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return response;
    
    HINTERNET hConnect = WinHttpConnect(hSession, whost.c_str(), port, 0);
    if (!hConnect) { WinHttpCloseHandle(hSession); return response; }
    
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", wpath.c_str(),
                                           NULL, WINHTTP_NO_REFERER,
                                           WINHTTP_DEFAULT_ACCEPT_TYPES,
                                           use_https ? WINHTTP_FLAG_SECURE : 0);
    if (!hRequest) {
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        return response;
    }
    
    if (WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                          NULL, 0, 0, 0) &&
        WinHttpReceiveResponse(hRequest, NULL)) {
        DWORD dwSize = 0, dwDownloaded = 0;
        char buffer[BUFFER_SIZE];
        do {
            dwSize = 0;
            if (WinHttpQueryDataAvailable(hRequest, &dwSize) && dwSize > 0) {
                if (dwSize > BUFFER_SIZE - 1) dwSize = BUFFER_SIZE - 1;
                if (WinHttpReadData(hRequest, buffer, dwSize, &dwDownloaded) && dwDownloaded > 0) {
                    buffer[dwDownloaded] = '\0';
                    response += buffer;
                }
            }
        } while (dwSize > 0);
    }
    
    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return response;
}
#else
std::string http_get_curl(const std::string& url) {
    CURL* curl = curl_easy_init();
    std::string response;
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,
            [](char* ptr, size_t size, size_t nmemb, std::string* data) -> size_t {
                data->append(ptr, size * nmemb);
                return size * nmemb;
            });
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        curl_easy_perform(curl);
        curl_easy_cleanup(curl);
    }
    return response;
}
#endif

// ==================== 转发器（跨平台） ====================
class TunnelForwarder {
private:
    socket_t udp_sock;
    struct sockaddr_in peer_addr;
    bool is_server_mode;
    int service_port;

public:
    TunnelForwarder(socket_t udp_fd, const std::string& peer_ip, int peer_port, bool server)
        : udp_sock(udp_fd), is_server_mode(server), service_port(GLOBAL_SERVICE_PORT) {
        memset(&peer_addr, 0, sizeof(peer_addr));
        peer_addr.sin_family = AF_INET;
        peer_addr.sin_port = htons(peer_port);
        inet_pton(AF_INET, peer_ip.c_str(), &peer_addr.sin_addr);
    }

    void start() {
        if (is_server_mode) {
            std::cout << "🔄 服务端模式: 127.0.0.1:" << service_port << " → UDP" << std::endl;
            std::thread(&TunnelForwarder::tcp_to_udp, this).detach();
            std::thread(&TunnelForwarder::udp_to_tcp_server, this).detach();
        } else {
            std::cout << "🔄 客户端模式: UDP → 127.0.0.1:" << (service_port + 1) << std::endl;
            std::thread(&TunnelForwarder::udp_to_tcp_client, this).detach();
            std::thread(&TunnelForwarder::tcp_to_udp_client, this).detach();
        }
    }

private:
    void tcp_to_udp() {
        socket_t tcp_server = socket(AF_INET, SOCK_STREAM, 0);
        if (tcp_server == INVALID_SOCKET_VAL) return;
        
        int opt = 1;
        setsockopt(tcp_server, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt));
        
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(service_port);
        
        if (bind(tcp_server, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            std::cerr << "❌ 端口 " << service_port << " 绑定失败" << std::endl;
            CLOSE_SOCKET(tcp_server);
            return;
        }
        
        listen(tcp_server, 5);
        std::cout << "✅ 监听本地端口: " << service_port << std::endl;
        
        while (g_running) {
            socket_t tcp_client = accept(tcp_server, NULL, NULL);
            if (tcp_client == INVALID_SOCKET_VAL) continue;
            
            std::cout << "🔗 客户端连接" << std::endl;
            std::thread([this, tcp_client]() {
                char buffer[BUFFER_SIZE];
                while (g_running) {
                    int len = recv(tcp_client, buffer, sizeof(buffer), 0);
                    if (len <= 0) break;
                    sendto(udp_sock, buffer, len, 0,
                           (struct sockaddr*)&peer_addr, sizeof(peer_addr));
                }
                CLOSE_SOCKET(tcp_client);
            }).detach();
        }
        CLOSE_SOCKET(tcp_server);
    }

    void udp_to_tcp_server() {
        socket_t tcp_client = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        addr.sin_port = htons(service_port);
        
        while (g_running) {
            if (connect(tcp_client, (struct sockaddr*)&addr, sizeof(addr)) == 0) break;
            SLEEP_MS(500);
        }
        
        std::cout << "✅ UDP转发器已连接本地服务" << std::endl;
        
        char buffer[BUFFER_SIZE];
        while (g_running) {
            struct sockaddr_in from;
            socklen_t from_len = sizeof(from);
            int len = recvfrom(udp_sock, buffer, sizeof(buffer), 0,
                               (struct sockaddr*)&from, &from_len);
            if (len > 0) {
                if (from.sin_port == peer_addr.sin_port &&
                    from.sin_addr.s_addr == peer_addr.sin_addr.s_addr) {
                    send(tcp_client, buffer, len, 0);
                }
            }
        }
        CLOSE_SOCKET(tcp_client);
    }

    void udp_to_tcp_client() {
        socket_t tcp_server = socket(AF_INET, SOCK_STREAM, 0);
        if (tcp_server == INVALID_SOCKET_VAL) return;
        
        int opt = 1;
        setsockopt(tcp_server, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt));
        
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(service_port + 1);
        
        if (bind(tcp_server, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            std::cerr << "❌ 绑定端口 " << (service_port + 1) << " 失败" << std::endl;
            CLOSE_SOCKET(tcp_server);
            return;
        }
        
        listen(tcp_server, 1);
        std::cout << "✅ 请连接: 127.0.0.1:" << (service_port + 1) << std::endl;
        
        socket_t tcp_client = accept(tcp_server, NULL, NULL);
        if (tcp_client == INVALID_SOCKET_VAL) return;
        std::cout << "🔗 客户端已连接" << std::endl;
        
        char buffer[BUFFER_SIZE];
        while (g_running) {
            struct sockaddr_in from;
            socklen_t from_len = sizeof(from);
            int len = recvfrom(udp_sock, buffer, sizeof(buffer), 0,
                               (struct sockaddr*)&from, &from_len);
            if (len > 0) {
                if (from.sin_port == peer_addr.sin_port &&
                    from.sin_addr.s_addr == peer_addr.sin_addr.s_addr) {
                    send(tcp_client, buffer, len, 0);
                }
            }
        }
        CLOSE_SOCKET(tcp_client);
        CLOSE_SOCKET(tcp_server);
    }

    void tcp_to_udp_client() {
        socket_t tcp_server = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(service_port + 1);
        bind(tcp_server, (struct sockaddr*)&addr, sizeof(addr));
        listen(tcp_server, 1);
        
        socket_t tcp_client = accept(tcp_server, NULL, NULL);
        if (tcp_client == INVALID_SOCKET_VAL) return;
        
        char buffer[BUFFER_SIZE];
        while (g_running) {
            int len = recv(tcp_client, buffer, sizeof(buffer), 0);
            if (len <= 0) break;
            sendto(udp_sock, buffer, len, 0,
                   (struct sockaddr*)&peer_addr, sizeof(peer_addr));
        }
        CLOSE_SOCKET(tcp_client);
        CLOSE_SOCKET(tcp_server);
    }
};

// ==================== 信令服务器 ====================
class SignalingServer {
private:
    socket_t server_fd;
    int port;
    std::thread accept_thread;

public:
    SignalingServer(int p) : port(p), server_fd(INVALID_SOCKET_VAL) {
#ifdef _WIN32
        WSADATA wsaData;
        WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif
    }

    ~SignalingServer() {
        g_running = false;
        if (server_fd != INVALID_SOCKET_VAL) {
            CLOSE_SOCKET(server_fd);
        }
        if (accept_thread.joinable()) accept_thread.join();
#ifdef _WIN32
        WSACleanup();
#endif
    }

    bool start() {
        server_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (server_fd == INVALID_SOCKET_VAL) {
            std::cerr << "socket创建失败" << std::endl;
            return false;
        }
        
        int opt = 1;
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt));
        
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(port);
        
        if (bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            std::cerr << "bind失败" << std::endl;
            CLOSE_SOCKET(server_fd);
            return false;
        }
        
        if (listen(server_fd, 100) < 0) {
            std::cerr << "listen失败" << std::endl;
            CLOSE_SOCKET(server_fd);
            return false;
        }
        
        std::cout << "✅ 信令服务器启动在端口 " << port << std::endl;
        accept_thread = std::thread(&SignalingServer::accept_loop, this);
        return true;
    }

private:
    void accept_loop() {
        while (g_running) {
            struct sockaddr_in addr;
            socklen_t len = sizeof(addr);
            socket_t client_fd = accept(server_fd, (struct sockaddr*)&addr, &len);
            if (client_fd == INVALID_SOCKET_VAL) continue;
            
            std::thread([this, client_fd, addr]() {
                handle_client(client_fd, addr);
            }).detach();
        }
    }

    void handle_client(socket_t client_fd, struct sockaddr_in addr) {
        char buffer[BUFFER_SIZE] = {0};
        int valread = recv(client_fd, buffer, BUFFER_SIZE - 1, 0);
        if (valread <= 0) {
            CLOSE_SOCKET(client_fd);
            return;
        }
        
        std::string client_ip = inet_ntoa(addr.sin_addr);
        int client_port = ntohs(addr.sin_port);
        std::string request(buffer);
        
        std::string action = "", device_id = "", target_id = "";
        size_t pos = request.find("action=");
        if (pos != std::string::npos) {
            size_t end = request.find("&", pos);
            action = request.substr(pos + 7, end - pos - 7);
        }
        pos = request.find("id=");
        if (pos != std::string::npos) {
            size_t end = request.find("&", pos);
            device_id = request.substr(pos + 3, end - pos - 3);
        }
        pos = request.find("target=");
        if (pos != std::string::npos) {
            size_t end = request.find("&", pos);
            target_id = request.substr(pos + 7, end - pos - 7);
        }
        
        clean_timeout();
        std::string response = process_action(action, device_id, target_id, client_ip, client_port);
        
        std::string http_response =
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/json\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "Connection: close\r\n"
            "Content-Length: " + std::to_string(response.length()) + "\r\n"
            "\r\n" + response;
        
        send(client_fd, http_response.c_str(), http_response.length(), 0);
        CLOSE_SOCKET(client_fd);
    }

    std::string process_action(const std::string& action, const std::string& device_id,
                               const std::string& target_id, const std::string& ip, int port) {
        if (action == "register") return handle_register(device_id, ip, port);
        if (action == "unregister") return handle_unregister(device_id);
        if (action == "list") return handle_list();
        if (action == "get_target") return handle_get_target(target_id);
        if (action == "check_id") return handle_check_id(device_id);
        if (action == "ping") return handle_ping(device_id);
        if (action == "stats") return handle_stats();
        return "{\"status\":\"error\",\"msg\":\"未知命令\"}";
    }

    std::string handle_register(const std::string& id, const std::string& ip, int port) {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        if (id.length() < MIN_ID_LENGTH || id.length() > MAX_ID_LENGTH) {
            return "{\"status\":\"error\",\"msg\":\"ID长度必须" + 
                   std::to_string(MIN_ID_LENGTH) + "-" + std::to_string(MAX_ID_LENGTH) + "字符\"}";
        }
        auto it = g_clients.find(id);
        if (it != g_clients.end() && it->second.is_permanent) {
            return "{\"status\":\"error\",\"msg\":\"ID已被永久占用\"}";
        }
        ClientInfo info{id, ip, port, time(nullptr), true};
        g_clients[id] = info;
        std::cout << "[注册] " << id << " (" << ip << ":" << port << ")" << std::endl;
        return "{\"status\":\"ok\",\"id\":\"" + id + "\",\"ip\":\"" + ip + 
               "\",\"port\":" + std::to_string(port) + "}";
    }

    std::string handle_unregister(const std::string& id) {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        if (g_clients.erase(id) > 0) {
            std::cout << "[注销] " << id << std::endl;
            return "{\"status\":\"ok\",\"msg\":\"已注销\"}";
        }
        return "{\"status\":\"error\",\"msg\":\"设备不在线\"}";
    }

    std::string handle_list() {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        std::string result = "{\"clients\":[";
        bool first = true;
        for (auto& pair : g_clients) {
            if (!first) result += ",";
            result += "{\"id\":\"" + pair.second.id + "\",\"ip\":\"" + pair.second.ip + 
                      "\",\"port\":" + std::to_string(pair.second.port) + ",\"permanent\":true}";
            first = false;
        }
        result += "],\"count\":" + std::to_string(g_clients.size()) + "}";
        return result;
    }

    std::string handle_get_target(const std::string& target_id) {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        auto it = g_clients.find(target_id);
        if (it != g_clients.end()) {
            return "{\"status\":\"ok\",\"target\":{\"id\":\"" + it->second.id + 
                   "\",\"ip\":\"" + it->second.ip + "\",\"port\":" + 
                   std::to_string(it->second.port) + "}}";
        }
        return "{\"status\":\"error\",\"msg\":\"目标不在线\"}";
    }

    std::string handle_check_id(const std::string& id) {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        if (id.length() < MIN_ID_LENGTH || id.length() > MAX_ID_LENGTH) {
            return "{\"status\":\"error\",\"msg\":\"ID长度不符合要求\"}";
        }
        if (g_clients.find(id) != g_clients.end()) {
            return "{\"status\":\"taken\",\"msg\":\"ID已被占用\"}";
        }
        return "{\"status\":\"available\",\"msg\":\"ID可用\"}";
    }

    std::string handle_ping(const std::string& id) {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        auto it = g_clients.find(id);
        if (it != g_clients.end()) {
            it->second.last_seen = time(nullptr);
            return "{\"status\":\"ok\",\"msg\":\"pong\"}";
        }
        return "{\"status\":\"error\",\"msg\":\"设备未注册\"}";
    }

    std::string handle_stats() {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        return "{\"status\":\"ok\",\"total_clients\":" + 
               std::to_string(g_clients.size()) + "}";
    }

    void clean_timeout() {
        std::lock_guard<std::mutex> lock(g_clients_mutex);
        time_t now = time(nullptr);
        for (auto it = g_clients.begin(); it != g_clients.end();) {
            if (!it->second.is_permanent && (now - it->second.last_seen) > TIMEOUT_SECONDS) {
                it = g_clients.erase(it);
            } else {
                ++it;
            }
        }
    }
};

// ==================== P2P客户端 ====================
class P2PClient {
private:
    std::string server_url, device_id, my_id;
    int udp_port;
    bool registered;

public:
    P2PClient(const std::string& url, const std::string& id) 
        : server_url(url), device_id(id), registered(false) {
#ifdef _WIN32
        WSADATA wsaData;
        WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif
        srand((unsigned)time(NULL) + GET_PID());
        udp_port = rand() % 40000 + 20000;
        
        if (id.length() < MIN_ID_LENGTH || id.length() > MAX_ID_LENGTH) {
            std::cerr << "❌ ID长度必须" << MIN_ID_LENGTH << "-" << MAX_ID_LENGTH << "字符" << std::endl;
            exit(1);
        }
    }

    ~P2PClient() {
        if (registered) unregister_device();
#ifdef _WIN32
        WSACleanup();
#endif
    }

    bool register_device() {
        std::string url = server_url + "/?action=register&id=" + url_encode(device_id);
        std::string response = HTTP_GET(url);
        std::string status = extract_json_value(response, "status");
        if (status != "ok") {
            std::cout << "❌ 注册失败: " << extract_json_value(response, "msg") << std::endl;
            return false;
        }
        my_id = extract_json_value(response, "id");
        std::cout << "✅ 注册成功！ID: " << my_id << std::endl;
        registered = true;
        return true;
    }

    bool unregister_device() {
        std::string url = server_url + "/?action=unregister&id=" + url_encode(device_id);
        std::string response = HTTP_GET(url);
        if (extract_json_value(response, "status") == "ok") {
            std::cout << "✅ 注销成功" << std::endl;
            return true;
        }
        return false;
    }

    std::vector<std::map<std::string, std::string>> get_online_clients() {
        std::vector<std::map<std::string, std::string>> clients;
        std::string response = HTTP_GET(server_url + "/?action=list");
        size_t pos = response.find("\"clients\":[");
        if (pos == std::string::npos) return clients;
        size_t start = response.find("{", pos);
        while (start != std::string::npos) {
            size_t end = response.find("}", start);
            if (end == std::string::npos) break;
            std::string item = response.substr(start, end - start + 1);
            std::map<std::string, std::string> client;
            client["id"] = extract_json_value(item, "id");
            client["ip"] = extract_json_value(item, "ip");
            client["port"] = extract_json_value(item, "port");
            clients.push_back(client);
            start = response.find("{", end + 1);
        }
        return clients;
    }

    bool get_target_info(const std::string& target_id, std::string& ip, int& port) {
        std::string response = HTTP_GET(server_url + "/?action=get_target&target=" + url_encode(target_id));
        if (extract_json_value(response, "status") != "ok") return false;
        size_t pos = response.find("\"target\":");
        if (pos == std::string::npos) return false;
        size_t start = response.find("{", pos);
        size_t end = response.find("}", start);
        if (start == std::string::npos || end == std::string::npos) return false;
        std::string target_json = response.substr(start, end - start + 1);
        ip = extract_json_value(target_json, "ip");
        std::string port_str = extract_json_value(target_json, "port");
        if (port_str.empty()) return false;
        port = std::stoi(port_str);
        return true;
    }

    void run() {
        if (!register_device()) return;
        
        std::cout << "\n╔════════════════════════════════════════════╗" << std::endl;
        std::cout << "║  P2P打洞系统 v" << VERSION << "                      ║" << std::endl;
        std::cout << "╠════════════════════════════════════════════╣" << std::endl;
        std::cout << "║  ID: " << device_id;
        for (int i = (int)device_id.length(); i < 36; i++) std::cout << " ";
        std::cout << "║" << std::endl;
        std::cout << "║  端口: " << GLOBAL_SERVICE_PORT;
        for (int i = std::to_string(GLOBAL_SERVICE_PORT).length(); i < 28; i++) std::cout << " ";
        std::cout << "║" << std::endl;
        std::cout << "╚════════════════════════════════════════════╝" << std::endl;
        
        std::cout << "\n选择模式:\n  1. 服务端\n  2. 客户端\n  3. 在线列表\n  4. 检查ID\n  0. 退出\n请输入: ";
        int choice;
        std::cin >> choice;
        
        switch (choice) {
            case 1: server_mode(); break;
            case 2: client_mode(); break;
            case 3: list_devices(); break;
            case 4: check_id(); break;
            default: break;
        }
    }

    void list_devices() {
        auto clients = get_online_clients();
        std::cout << "\n在线设备 (" << clients.size() << " 个):" << std::endl;
        for (auto& c : clients) {
            std::cout << "  " << c["id"] << " (" << c["ip"] << ":" << c["port"] << ")" << std::endl;
        }
    }

    void check_id() {
        std::string response = HTTP_GET(server_url + "/?action=check_id&id=" + url_encode(device_id));
        std::cout << "ID状态: " << extract_json_value(response, "status") 
                  << " - " << extract_json_value(response, "msg") << std::endl;
    }

    socket_t create_udp_socket(int port) {
        socket_t sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock == INVALID_SOCKET_VAL) return INVALID_SOCKET_VAL;
        int opt = 1;
        setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt));
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(port);
        if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            CLOSE_SOCKET(sock);
            return INVALID_SOCKET_VAL;
        }
        return sock;
    }

    void server_mode() {
        std::cout << "\n📡 服务端模式，等待连接...\n";
        socket_t udp_sock = create_udp_socket(udp_port);
        if (udp_sock == INVALID_SOCKET_VAL) return;
        std::cout << "UDP端口: " << udp_port << std::endl;
        std::cout << "设备ID: " << device_id << std::endl;
        
        char buffer[1024];
        struct sockaddr_in peer;
        socklen_t peer_len = sizeof(peer);
        while (g_running) {
            int len = recvfrom(udp_sock, buffer, sizeof(buffer), 0,
                               (struct sockaddr*)&peer, &peer_len);
            if (len > 0) {
                char ip[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &peer.sin_addr, ip, INET_ADDRSTRLEN);
                int port = ntohs(peer.sin_port);
                std::cout << "\n✅ P2P连接建立! " << ip << ":" << port << std::endl;
                sendto(udp_sock, "ACK", 3, 0, (struct sockaddr*)&peer, peer_len);
                TunnelForwarder f(udp_sock, ip, port, true);
                f.start();
                std::cout << "✅ 服务就绪，按Ctrl+C退出" << std::endl;
                while (g_running) SLEEP_MS(1000);
                break;
            }
        }
        CLOSE_SOCKET(udp_sock);
    }

    void client_mode() {
        std::cout << "\n🖥️ 客户端模式" << std::endl;
        std::cout << "目标设备ID: ";
        std::string target_id;
        std::cin >> target_id;
        if (target_id == device_id) {
            std::cout << "❌ 不能连接自己" << std::endl;
            return;
        }
        std::string ip; int port;
        if (!get_target_info(target_id, ip, port)) {
            std::cout << "❌ 目标不在线" << std::endl;
            return;
        }
        std::cout << "目标: " << target_id << " (" << ip << ":" << port << ")" << std::endl;
        std::cout << "🔨 开始打洞..." << std::endl;
        
        socket_t udp_sock = create_udp_socket(udp_port);
        if (udp_sock == INVALID_SOCKET_VAL) return;
        
        struct sockaddr_in target_addr;
        target_addr.sin_family = AF_INET;
        target_addr.sin_port = htons(port);
        inet_pton(AF_INET, ip.c_str(), &target_addr.sin_addr);
        sendto(udp_sock, "P2P", 3, 0, (struct sockaddr*)&target_addr, sizeof(target_addr));
        std::cout << "📤 发送打洞包到 " << ip << ":" << port << std::endl;
        
        char buffer[1024];
        struct sockaddr_in peer;
        socklen_t peer_len = sizeof(peer);
        for (int i = 0; i < MAX_RETRY; i++) {
            int len = recvfrom(udp_sock, buffer, sizeof(buffer), 0,
                               (struct sockaddr*)&peer, &peer_len);
            if (len > 0) {
                char peer_ip[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &peer.sin_addr, peer_ip, INET_ADDRSTRLEN);
                int peer_port = ntohs(peer.sin_port);
                std::cout << "📩 收到回复!" << std::endl;
                std::cout << "🎉 P2P连接成功!" << std::endl;
                TunnelForwarder f(udp_sock, peer_ip, peer_port, false);
                f.start();
                std::cout << "✅ 隧道已建立，连接 127.0.0.1:" << (GLOBAL_SERVICE_PORT + 1) << std::endl;
                while (g_running) SLEEP_MS(1000);
                break;
            }
            std::cout << "⏳ 等待... (" << (i+1) << "/" << MAX_RETRY << ")" << std::endl;
        }
        CLOSE_SOCKET(udp_sock);
    }
};

// ==================== 信号处理 ====================
#ifdef _WIN32
BOOL WINAPI ConsoleHandler(DWORD dwCtrlType) {
    if (dwCtrlType == CTRL_C_EVENT || dwCtrlType == CTRL_BREAK_EVENT) {
        std::cout << "\n正在退出..." << std::endl;
        g_running = false;
        return TRUE;
    }
    return FALSE;
}
#else
void SignalHandler(int sig) {
    if (sig == SIGINT || sig == SIGTERM) {
        std::cout << "\n正在退出..." << std::endl;
        g_running = false;
    }
}
#endif

// ==================== 主程序 ====================
int main(int argc, char* argv[]) {
#ifdef _WIN32
    SetConsoleCtrlHandler(ConsoleHandler, TRUE);
#else
    signal(SIGINT, SignalHandler);
    signal(SIGTERM, SignalHandler);
#endif
    
    if (argc < 3) {
        std::cout << "╔══════════════════════════════════════════════════════╗" << std::endl;
        std::cout << "║  P2P打洞系统 v" << VERSION << " (跨平台)                ║" << std::endl;
        std::cout << "╠══════════════════════════════════════════════════════╣" << std::endl;
        std::cout << "║  用法:                                             ║" << std::endl;
        std::cout << "║    server <端口>                                   ║" << std::endl;
        std::cout << "║    client <URL> <端口> <ID>                       ║" << std::endl;
        std::cout << "╠══════════════════════════════════════════════════════╣" << std::endl;
        std::cout << "║  示例:                                             ║" << std::endl;
        std::cout << "║    p2p_enterprise server 8080                     ║" << std::endl;
        std::cout << "║    p2p_enterprise client http://IP:8080 22 my-id  ║" << std::endl;
        std::cout << "╚══════════════════════════════════════════════════════╝" << std::endl;
        return 1;
    }
    
    std::string mode = argv[1];
    
    if (mode == "server") {
        int port = atoi(argv[2]);
        if (port == 0) port = DEFAULT_PORT;
        SignalingServer server(port);
        if (!server.start()) return 1;
        std::cout << "按 Ctrl+C 退出" << std::endl;
        while (g_running) SLEEP_MS(1000);
    }
    else if (mode == "client") {
        if (argc < 5) {
            std::cerr << "❌ 需要: URL 端口 ID" << std::endl;
            return 1;
        }
        std::string server_url = argv[2];
        GLOBAL_SERVICE_PORT = atoi(argv[3]);
        std::string device_id = argv[4];
        P2PClient client(server_url, device_id);
        client.run();
    }
    else {
        std::cerr << "❌ 未知模式: " << mode << std::endl;
        return 1;
    }
    
    return 0;
}