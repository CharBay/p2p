# P2P打洞系统 v3.0

## 编译

### 使用CMake
```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build .