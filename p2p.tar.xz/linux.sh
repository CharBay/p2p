#!/bin/bash
# build_linux.sh - Linux一键编译脚本

echo "╔══════════════════════════════════════════════════════╗"
echo "║  P2P打洞系统 - Linux编译脚本                       ║"
echo "╚══════════════════════════════════════════════════════╝"
echo

# 检查依赖
echo "[1] 检查依赖..."
if ! command -v g++ &> /dev/null; then
    echo "❌ 未安装g++，请运行: sudo apt install g++ (Ubuntu) 或 sudo yum install gcc-c++ (CentOS)"
    exit 1
fi

if ! command -v curl-config &> /dev/null; then
    echo "⚠️ 未安装libcurl开发库"
    echo "   Ubuntu: sudo apt install libcurl4-openssl-dev"
    echo "   CentOS: sudo yum install libcurl-devel"
    exit 1
fi

echo "✅ 依赖检查通过"

# 编译
echo "[2] 开始编译..."
g++ -std=c++11 -O2 -o p2p src/p2p.cpp -lpthread -lcurl

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 编译成功! 生成: p2p"
    echo ""
    echo "使用示例:"
    echo "  信令服务器: ./p2p server 8080"
    echo "  客户端:     ./p2p client http://IP:8080 22 my-id"
    echo ""
    echo "安装到系统: sudo make install"
else
    echo "❌ 编译失败"
    exit 1
fi